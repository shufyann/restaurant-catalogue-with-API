import DataSource from '../data/data-source.js';
  
  const main = () => {
  const searchElement = document.querySelector('#searchElement');
  const buttonSearchElement = document.querySelector('#searchButtonElement');
  const foodListElement = document.querySelector('#clubList');
  
  const onButtonSearchClicked = async () => {
    try {
      const result = await DataSource.searchFood(searchElement.value);
      renderResult(result);
    } catch (message) {
      fallbackResult(message);
    }
  };
 
  const renderResult = results => {
    foodListElement.innerHTML = '';
    results.forEach(club => {
      const {strMealThumb, strMeal, idMeal} = club;
      const foodElement = document.createElement('div');
      foodElement.setAttribute('class', 'club');
 
      foodElement.innerHTML = `
      <img class="fan-art-food" src="${strMealThumb}" alt="">
      <div class="food-info">
        <h2>${strMeal}</h2>
        <p>${idMeal}</p>
      </div>
      `;
      
      foodListElement.appendChild(foodElement);
    });
  };
  
  const fallbackResult = message => {
    foodListElement.innerHTML = '';
    foodListElement.innerHTML += `<h2 class="placeholder">${message}</h2>`;
    };
 
  buttonSearchElement.addEventListener('click', onButtonSearchClicked);
};

export default main;